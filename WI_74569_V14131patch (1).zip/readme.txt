This TestFix applies to IBM® Developer for z Systems® 14.1.3.1

Details on the test fix:
~~~~~~~~~~~~~~~~~~~~~~~~
This test fix addresses the following problem- WI_74569_V14131:
Support complex dynamic CALL

How to install the test fix:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*** NOTE: It is mandatory to have IBM® Developer for z Systems® 14.1.3.1 
*** installed before applying this test fix

1. Extract WI_74569_V14131patch.zip to a directory.  
 For example to:
 Windows: c:\temp\WI_74569_V14131patch
 Linux and UNIX: /temp/WI_74569_V14131patch

2. Open a command prompt for directory 
 Windows: <install_dir>\IBM\Installation Manager\eclipse
 Linux and UNIX:  <install_dir>/IBM/InstallationManager/eclipse
   
3. Run the command:
 Windows: IBMIM -input c:\temp\WI_74569_V14131patch\install.xml
 Linux and UNIX: IBMIM -input /temp/WI_74569_V14131patch/install.xml

4. When Installation Manager starts, click Update to start the Update wizard.

5. Continue through the Update wizard to install the fix.

How to uninstall the test fix:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
1. Start IBM Installation Manager.
2. Select 'Uninstall', then TestFix 'WI_74569_V14131' and follow the flow.

Automatic uninstalls:
~~~~~~~~~~~~~~~~~~~~~
The TestFix is uninstalled automatically if there is no longer a package 
installed to which the test fix applies. 
This is checked during updates and rollbacks. 